#include "stack.h"

tStack *createStack(void)
{
    tStack *cre = (tStack*)malloc(sizeof(tStack));
    cre->count = 0;
    cre->head = NULL;
    return cre;
}

void handlePushOperation(tStack *pStack)
{
    int score;
    int mv_cnt = pStack->count;
	  
    if (pStack->count == N){
        printf ("[Error]  handlePushOperation(): space full \n");
        return;
    }
	    
    printf("  handlePushOperation(): enter score value: ");
    scanf("%d", &score);

    tNode* Node = (tNode*)malloc(sizeof(tNode));
    
    tTypeScore* dataptr;
    getScoreSpace(&dataptr);
    dataptr->used = 1;
    dataptr->score = score;
    
    Node->dataPtr = dataptr;
    Node->next = NULL;
    
    if (mv_cnt == 0){

        pStack->head = Node;
        pStack->count += 1;
    }
    else{
        
        tNode* pHeadNode = pStack->head;
        Node->next = pHeadNode;
        pStack->head = Node;
        pStack->count += 1;
    }
    
    return; 
}

void handlePopOperation(tStack *pStack)
{
    if (pStack->count == 0)
    {
        printf ("[Error]  handlePopOperation(): nothing in stack \n");
        return;
    }
	    

    tNode* pHeadNextNode = pStack->head->next;
	tNode* pHeadNode = pStack->head;

	printf("  handlePopOperation(): poped value: %d\n", pHeadNode->dataPtr->score);
	returnScoreSpace(pStack->head->dataPtr->loc);

    pStack->head = pHeadNextNode;
    pStack->count -= 1;
    pHeadNode->dataPtr->score = 0;
    pHeadNode->dataPtr->loc = 0;
    pHeadNode->dataPtr->used = 0;

}

void printStackContent(tStack *pStack)
{

    tNode* pNode = pStack->head;
    
    printf("\n");
    printf("   printStackContent(): stack items -> ");
    for(int i = 0; i < pStack->count; i++){
        printf(" %d(%d) ", pNode->dataPtr->score, pNode->dataPtr->loc);
        pNode = pNode->next;
    }
    printf("\n");


}

